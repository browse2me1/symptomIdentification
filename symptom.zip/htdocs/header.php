<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Symptom Checker</title>
    <link rel="stylesheet" href="style.css">
</head>
<header> 
        <img src="logo.png" alt="Logo">  
      <h1>Symptom-Based Disease Identification System</h1>
      <p>select your symptoms to identify possible diseases</p>
    </header>