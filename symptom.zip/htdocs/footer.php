 <footer>
            <p>University of Gondar &copy; 2025 | Department of Health Informatics</p>
</footer>